#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

int doParsing();

#endif // PARSER_H_INCLUDED
