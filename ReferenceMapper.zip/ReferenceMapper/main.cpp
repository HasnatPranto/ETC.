#include <iostream>
#include "mapper.h"
#include "parser.h"

using namespace std;

int main()
{
    int sw=0;

    cout << "**********Reference Mapper*************\n";

    while(sw!=3)
    {
        cout << "\n1.Parse Text Files into XML\n2.Map References of Authors\n3.Exit\nEnter Your Choice: ";
        cin >> sw;

        switch(sw)
        {
            case 1: doParsing();
                    break;
            case 2: doMapping();

        }


    }
    cout << "Hello world!" << endl;
    return 0;
}
